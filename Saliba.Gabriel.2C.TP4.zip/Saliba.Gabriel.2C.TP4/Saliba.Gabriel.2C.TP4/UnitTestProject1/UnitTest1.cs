﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// Test que verifica que la lista de Paquetes del Correo esté instanciada.
        /// </summary>
        [TestMethod]
        public void TestListaPaquetesCorreoInstanciada()
        {
            //Arrange
            Correo correo = new Correo();
            //Act
            Assert.IsNotNull(correo.Paquetes);
        }

        /// <summary>
        /// Test que verifica que no se puedan cargar dos Paquetes con el mismo Tracking ID.
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(TrackingIdRepetidoException))]
        public void TestNoPoderCargarDosPaquetesConMismoTrackingID()
        {
            //Arrange
            Correo correo = new Correo();
            Paquete pqtUno = new Paquete("Alberdi", "540");
            Paquete pqtDos = new Paquete("Quilmes", "540");
            
            //Act
            correo += pqtUno;
            correo += pqtDos;
        }
    }
}
